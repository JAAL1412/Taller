
<?php $__env->startSection('titulo', 'Busqueda'); ?>
<?php $__env->startSection('contenido'); ?>

<form action="<?php echo e(route('vehiculo.index')); ?>" method="POST">
		<?php echo csrf_field(); ?>
        <div class="input-group-text mb-3">
            <input type="text" class="form-control" name="search" placeholder="Placa del vehículo">
            <button class="btn" type="sumbmit" name="bt" value=1>Buscar</button>
        </div>

		</form>

  </section>    
  <?php if($x): ?>
    <section class="container" style="background-color: transparent;">
        <table class="table">
            <thead>
                <tr style="border-bottom: 1mm solid #ffc107;">
                    <th style="border-left: transparent !important;" class="t">ID</th>
                    <th scope="col" class="t">Placa</th>
                    <th scope="col" class="t">Color</th>
                    <th scope="col" class="t">Modelo</th>
                    <th scope="col" class="t">Dueño</th>
                    <th scope="col" class="t">Acción</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $datos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr style="border-left: transparent;">
                        <td style="border-left: transparent !important;" class="t"><?php echo e($item->vid); ?></td>
                        <td class="t"><?php echo e($item->placa); ?></td>
                        <td class="t"><?php echo e($item->color); ?></td>
                        <td class="t"><?php echo e($item->modelo); ?></td>
                        <td class="t"><?php echo e($item->nombre); ?> <?php echo e($item->apellido); ?></td>
                        <td class="t">
                            <form action="<?php echo e(route('vehiculo.edit', $item->placa)); ?>" method="GET">
                                <button class="btn btn-warning btn-sm">
                                    <ion-icon name="create-outline"></ion-icon>
                                </button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

        <table class="table">
            <h2 class="title" style="border-radius: 10px; background-color:#2c0c00;">
                Historial
            </h2>
            <thead>
                <tr style="border-bottom: 1mm solid #ffc107;">
                    <th scope="col" style="border-left: transparent !important;" class="t">Id</th>
                    <th scope="col" class="t">Ingreso</th>
                    <th scope="col" class="t">Salida</th>
                    <th scope="col" class="t">Reparacion</th>
                    <th scope="col" class="t">Monto</th>
                    <th scope="col" class="t">Comentario</th>
                    <th scope="col" class="t">Acción</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $datoh; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dato): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td style="border-left: transparent !important;" class="t"><?php echo e($dato->id); ?></td>
                        <td class="t"><?php echo e($dato->ingreso); ?></td>
                        <td class="t"><?php echo e($dato->salida); ?></td>
                        <td class="t"><?php echo e($dato->reparacion); ?></td>
                        <td class="t"><?php echo e($dato->monto); ?></td>
                        <td class="t"><?php echo e($dato->comentario); ?></td>
                        <td class="t">
                            <form action="<?php echo e(route('vehiculo.edit', $dato->placav)); ?>" method="GET">
                                <button class="btn btn-warning btn-sm">
                                    <ion-icon name="create-outline"></ion-icon>
                                </button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </section>
<?php endif; ?>
<?php $__env->stopSection(); ?>






<?php echo $__env->make('Layout/plantilla2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\jacie\Taller\resources\views/busqueda.blade.php ENDPATH**/ ?>