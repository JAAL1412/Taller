<?php $__env->startSection('titulo', 'historial'); ?>
<?php $__env->startSection('contenido'); ?>

<form action="<?php echo e(route('historial.store')); ?>" method="POST">
		<?php echo csrf_field(); ?>
     <button type="button" class="btn" data-bs-toggle="modal" data-bs-target="#Modal">
      Añadir Entrada
    </button>

<div class="modal fade" id="Modal" tabindex="-1" aria-labelledby="ModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5 title" id="ModalLabel">Dato sobre el ingreso</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <div>
        <select class="form-select form-control" name="vehiculo">
      <option selected>Vehiculos</option>
      <?php $__currentLoopData = $vehiculos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vehiculos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <option value="<?php echo e($vehiculos->placa); ?>"><?php echo e($vehiculos->placa); ?>-<?php echo e($vehiculos->modelo); ?></option>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <br>
    <label class="form-label">Comentario</label>
            <input type="text" class="form-control" name="comentario" placeholder="comentario">
        </div>
      </div>
      <div class="modal-footer">
        <button class="btn col col-md-4" type="submit">Agregar</button>  
      </div>
    </div>
  </div>
</div>
</form>

<table>
        <thead>
          <tr style="border-bottom: 2mm solid #ffc107 !important;">
            <th style="border-left: transparent !important;" class="t">ID</th>
            <th class="t">Placa</th>
            <th class="t">Entrada</th>
            <th class="t">Salida</th>
            <th class="t">Trabajo Realizado</th>
            <th class="t">comentario</th>
            <th class="t">Accion</th>
        
          </tr>
        </thead>
        <tbody>
          <?php $__currentLoopData = $historial; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         
          <tr>
            <td style="border-left:transparent !important;" class="t"><?php echo e($item->id); ?></td>
            <td class="t"><a class="aplaca" href="<?php echo e(route('vehiculo.busqueda', $item->placav )); ?>" method="GET"><?php echo e($item->placav); ?></a>
              </td>
            <td class="t"><?php echo e($item->ingreso); ?></td>
            <td class="t"><?php echo e($item->salida); ?></td>
            <td class="t"><?php echo e($item->reparacion); ?></td>
            <td class="t"><?php echo e($item->comenta1); ?> <br> </td>
            <td class="t">


            <button class="btn"  style="background-color: red;" data-bs-toggle="modal" data-bs-target="#<?php echo e($item->id); ?>1">
              <ion-icon name="create-outline">editar</ion-icon>       
            </button> 
            <button class="btn" style="background-color: red;" data-bs-toggle="modal" data-bs-target="#<?php echo e($item->id); ?>2">
                <ion-icon name="log-out-outline"></ion-icon>
              </button>

            <form action="<?php echo e(route('historialr.salida')); ?>" method="POST">
              <?php echo csrf_field(); ?>
              <div class="modal fade"  id="<?php echo e($item->id); ?>1" tabindex="-1" aria-labelledby="ModalLabel" aria-hidden="true">
                <div class="modal-dialog" >
                  <div class="modal-content" style="background-color: black;">
                    <div class="modal-header" style="border-bottom: .5mm solid #ffc107;">
                      <h1 class="modal-title fs-5" id="<?php echo e($item->id); ?>1">
                        Ingrese los nuevos datos
                      </h1>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                    <div> 
            <label class="form-label">Reparación realizada</label>
            <br>
            <input type="text" class="form-control" name="reparacion" value="<?php echo e($item->reparacion); ?>">
            <br>
            <label class="form-label">Comentario</label>
            <br>
            <input type="text" class="form-control" name="comentario" value="<?php echo e($item->comenta1); ?>">
        </div>
                    </div>
                    <div class="modal-footer">
                      <button class="btn col col-md-4" type="submit"  name="id" Value="<?php echo e($item->id); ?>">Editar</button>  
                    </div>
                  </div>
                </div>
              </div>
            </form>

             
<form action="<?php echo e(route('historial.salida')); ?>" method="POST">
              <?php echo csrf_field(); ?>
              <div class="modal fade"  id="<?php echo e($item->id); ?>2" tabindex="-1" aria-labelledby="ModalLabel" aria-hidden="true">
  <div class="modal-dialog" >
    <div class="modal-content" style="background-color: black;">
      <div class="modal-header" style="border-bottom: .5mm solid #ffc107;">
        <h1 class="modal-title fs-5" id="<?php echo e($item->id); ?>2Label">
          Ingrese Reparación realizada y  Monto cobrado
        </h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <div>
        <label class="form-label">Reparación</label><br>
            <input type="text" class="form-control" name="reparacion" value="<?php echo e($item->reparacion); ?>">
            <br>
            <label class="form-label">Monto</label><br>
            <input type="text" class="form-control" name="monto" value="<?php echo e($item->monto); ?>">
            <br>
            <label class="form-label">Concepto</label><br>
            <input type="text" name="concepto" class="form-control" value="<?php echo e($item->concepto); ?>">
            <br>
            <label class="form-label">Comentario</label><br>        
            <input type="text" class="form-control" name="comenta" value="<?php echo e($item->comenta2); ?>">
        </div>
      </div>
      <div class="modal-footer">
        <button class="btn col col-md-4" type="submit"  name="id"value="<?php echo e($item->id); ?>">Agregar</button>  
      </div>
    </div>
  </div>
</div>
          </form>
           </tr>
            
           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('Layout/plantilla2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\jacie\Taller\resources\views/historial.blade.php ENDPATH**/ ?>