
<style>
.bo{
    background-image: url(./img/personal.jpg);
    background-repeat: no-repeat;
    background-size: cover;
   }
   .container{
    background-color: rgb(44, 12, 0, .90);
    margin-top: 30px;
    margin-bottom: 50px;
    padding: 20px;
    }
    .title{
        text-align: center;
        color: #ffc107;

    }
    .form-label{
        color: #ffc107;
        max-width: 30%;
    }

    form{
        text-align: center;
    }
    .btn:hover{
        margin: 10px;
        background-color: #2c0c00;
        color:#ffc107;
        border: 1mm solid #2c0c00;
    }
.btn{
        margin: 10px;
        background-color: #ffc107;
        color:#2c0c00 ;
        border: 1mm solid #2c0c00;
    } 
.btn:hover{
        margin: 10px;
        background-color: #2c0c00;
        color:#ffc107;
        border: 1mm solid #2c0c00;
    }
.input-group-text{
        background-color: transparent;
        border-color:transparent;
}
</style><?php /**PATH F:\jacie\Taller\resources\views/Layout/styles.blade.php ENDPATH**/ ?>