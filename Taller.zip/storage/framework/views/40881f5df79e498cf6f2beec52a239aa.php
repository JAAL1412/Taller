<?php $__env->startSection('titulo', 'Inicio de sesión'); ?>
<?php $__env->startSection('contenido'); ?>

<div class="row">
    <div class="col-md-10 form1" style="margin: auto;">
   
    <h3 class="title">Iniciando sesión</h3>
    	<form action="<?php echo e(route('Users.verifica')); ?>" method="POST">
		<?php echo csrf_field(); ?>
			<div class="try">
				<label for="" class="form-label">Usuario</label>	
				<input type="text" name="User" class="form-control" required>
			</div>	
			<div class="try" >
				<label for="" class="form-label">Contraseña</label>	
				<input type="password" name="Contra" class="form-control"required>
			</div>	
			<button class="btn" type="submit">Entrar</button>
		</form>
    
    </div>
</div>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('Layout/plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\jacie\Taller\resources\views/welcome.blade.php ENDPATH**/ ?>