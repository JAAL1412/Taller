
<?php $__env->startSection('titulo', 'Editar'); ?>
<?php $__env->startSection('contenido'); ?>
<div class="row">
    <div class="col-md-10 form1" style="margin: auto;">

<form action="<?php echo e(route('vehiculo.up', $datos->id)); ?>" class="form" method="post">
    <?php echo csrf_field(); ?> 
        <h3 class="title">Editar información del vehiculo </h3>
        <br>
        <label class="form-label">Dueño</label>
        <br>
        <select class="form-select form-control" name="dueño">
            <option selected value="<?php echo e($datos->dueño); ?>"><?php echo e($dueño->nombre); ?><?php echo e($dueño->apellido); ?></option>
            <?php $__currentLoopData = $dueños; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($item->id); ?>" ><?php echo e($item->nombre); ?><?php echo e($item->apellido); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <br>
          <label class="form-label" name="placa">Placa</label>
          <input type="text" class="form-control" value="<?php echo e($datos->placa); ?>" name="placa" required />
          <br>
          <label class="form-label" name="año">Año de frabricacion</label>
          <input type="text" class="form-control" value="<?php echo e($datos->fecha_fabri); ?>" name="año" required />
          <br>
          <label class="form-label" name="color">Color </label>
          <input type="text" class="form-control" value="<?php echo e($datos->color); ?>" name="color" required />
          <br>
          <label class="form-label" name="modelo">Modelo</label>
          <input type="text" class="form-control" value="<?php echo e($datos->modelo); ?>" name= "modelo"required />
          <br>
          <label class="form-label" name="pais">País</label>
          <input type="text" class="form-control" value="<?php echo e($datos->pais); ?>" name="pais" required />
          <br>
          <button class="btn" type="submit" style="height: 50px; border:solid #2c0c00 2px; font-size:5mm;" >Editar</button>
            
      </form>
</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('Layout/plantilla2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\jacie\Taller\resources\views/dimas.blade.php ENDPATH**/ ?>